package com.example.hanyarunrun.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryColor = Color(0xFFD70654)
val PrimaryVariant = Color(0xFF3700B3)
val SecondaryColor = Color(0xFF03DAC5)
